Annotate these files as `grub`
